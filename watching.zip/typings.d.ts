interface JQuery {
    slick: any;
    elevateZoom: any;
    cnzipcode: any;
    selector: any;
    rate: any;
    swiper: any;
}
