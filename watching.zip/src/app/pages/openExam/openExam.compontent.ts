import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'table-cmp',
    moduleId: module.id,
    templateUrl: 'openExam.component.html'
})

export class OpenExamComponent implements OnInit {
    ngOnInit() {
    }
}
