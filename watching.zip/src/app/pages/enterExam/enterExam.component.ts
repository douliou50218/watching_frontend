import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'table-cmp',
    moduleId: module.id,
    templateUrl: 'enterExam.component.html'
})

export class EnterExamComponent implements OnInit {
    ngOnInit() {
    }
}
