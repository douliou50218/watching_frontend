import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'table-cmp',
    moduleId: module.id,
    templateUrl: 'addcraftPortfolio.component.html'
})

export class AddCraftPortfolioComponent implements OnInit {
    ngOnInit() {
    }
}
