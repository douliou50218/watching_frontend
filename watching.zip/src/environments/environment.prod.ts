export const environment = {
  production: false,
  keyOfToken: 'userToken'
};
